/* version.h - version defines for spfmilter */

#ifndef _VERSION_H_
#define _VERSION_H_

#define SPFMILTER_PROGRAM "spfmilter"
#define SPFMILTER_VERSION "0.92"
#define SPFMILTER_URL "http://www.acme.com/software/spfmilter/"

#endif /* _VERSION_H_ */
